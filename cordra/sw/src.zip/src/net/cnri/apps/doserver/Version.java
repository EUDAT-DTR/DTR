
       package net.cnri.apps.doserver;
       public class Version {
           public static final String version="2.5.18.20160130183822";
       }
    