/*************************************************************************\
    Copyright (c) 2015 Corporation for National Research Initiatives;
                        All rights reserved.
     The CNRI open source license for this software is available at
                  http://hdl.handle.net/20.1000/106
\*************************************************************************/

package net.cnri.apps.doserver;

// This class can be used with Logback to force the use of a logback.xml from the server directory.

public class LogbackContextInitializer { //extends ch.qos.logback.classic.util.ContextInitializer {
//    public LogbackContextInitializer(ch.qos.logback.classic.LoggerContext lc) {
//        super(lc);
//    }
}
