This package is for the application that controls the high level DO GUI client

