/*************************************************************************\
    Copyright (c) 2015 Corporation for National Research Initiatives;
                        All rights reserved.
     The CNRI open source license for this software is available at
                  http://hdl.handle.net/20.1000/106
\*************************************************************************/

package net.cnri.dobj;

public class HeaderItem {
  String name;
  String value;
    
  HeaderItem(String name, String value) {
    this.name = name;
    this.value = value;
  }

  public String getName() { return name; }
  public String getValue() { return value; }
  
  public String toString() {
    return name +": "+value;
  }

  @Override
  public int hashCode() {
      final int prime = 31;
      int result = 1;
      result = prime * result + ((name == null) ? 0 : name.hashCode());
      result = prime * result + ((value == null) ? 0 : value.hashCode());
      return result;
  }

  @Override
  public boolean equals(Object obj) {
      if (this == obj)
          return true;
      if (obj == null)
          return false;
      if (getClass() != obj.getClass())
          return false;
      HeaderItem other = (HeaderItem) obj;
      if (name == null) {
          if (other.name != null)
              return false;
      } else if (!name.equals(other.name))
          return false;
      if (value == null) {
          if (other.value != null)
              return false;
      } else if (!value.equals(other.value))
          return false;
      return true;
  }
}


