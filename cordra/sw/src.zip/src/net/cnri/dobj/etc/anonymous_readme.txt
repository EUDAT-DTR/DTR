The keys in anonymous_privkey.bin and anonymous_pubkey.bin are used
to authenticate with a server when the server doesn't care who the
client is.

The ID cnri.test.sean/anonymous references the public key in anonymous_pubkey.bin
and can therefore be used to authenticate using the private key in anonymous_privkey.bin.
